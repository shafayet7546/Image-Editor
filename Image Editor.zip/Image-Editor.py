import cv2

#Changes made: Scaled Image to 500x500, Changed color space to grayscale!

def Alter_Image(File, UserWidth, UserHeight, NewName):

        # Loaded Image
        img = cv2.imread(File)

        # Resized Image
        ImageResized = cv2.resize(img, (UserWidth, UserHeight))

        # Converted color space from BGR to grayscale
        ColorSpace = cv2.cvtColor(ImageResized, cv2.COLOR_BGR2GRAY)

        # Saved altered image to same folder
        cv2.imwrite(NewName, ColorSpace)


def main():
    # Passed in chosen image file to function, 'Alter_Image'
    ValidType = True

    #Program continues to run until dimensions are valid
    while ValidType:
        try:
            UserFile = input("Please input the name of the file, followed by it's data type (example: Picture1.png or Picture.jpg)")
            UserWidth = int(input("Input the width in pixels format: "))
            UserHeight = int(input("Input the height in pixels format: "))
            NewName = input("Please input the file name to save altered image as: ")
            NewFileType = input("Input the image file type in format(ex: .jpg, .png, .tiff, and more): ")
            NewName = NewName + NewFileType
            print("*****************************")
            File = UserFile
            Alter_Image(File, UserWidth, UserHeight, NewName)
            ValidType = False
        #Checks and catches wrong data type values for dimensions
        except ValueError:
            print("Invalid input for dimensions, Please input a whole number or decimal value, Try again!")
        
main()